WARNING:
Do NOT delete/alter ANY files/folders in these directories, unless you know what you're doing!

IF you want to create custom maps, go to these directories, maps/custom-map. There's a file called
"how-to.txt", use this file for further instructions!